import React from 'react'

export default function TotalScore() {
  return (
    <div>
       <h1>0</h1>
       <p>Total Score</p>
    </div>
  )
}
